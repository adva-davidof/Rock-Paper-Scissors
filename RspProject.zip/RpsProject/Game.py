import json
import os
import time

from Player import Player
from Version import Version

# permanent strings
SECTION = "~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~ ~"
INTRODUCTION = "Hi ! Welcome to improved rock pepper scissors game\n"
MENU = "0- for the game\n1- for the rules\n2- for inserting your own version\n3- to end the game"
RULES1 = "rules:\nThe game is for 2 players\nThe players pick a game version\nevery player picks"
RULES2 = " an element according to the version rules\n\nthe winner is chosen according to the rules of the version\n"
RULES = RULES1 + RULES2


class Game:
    """
    this class is in charge of running a game of rock paper scissors
    """

    def __init__(self):
        """
        initialize the players to an empty array
        set the default versions in the versions array
        """

        self.players = []
        self.versions = Version.insert_default_versions()

    def initialize_players(self):
        """
        convert the information from the user to player objects
        """
        print()  # for the design
        name1 = input("what is the first player's name?")
        name2 = input("what is the second player's name?")

        self.players = []
        self.players.append(Player(name1))
        self.players.append(Player(name2))
        print()  # for the design

    def run_game(self):
        """
        runs the game
        user picks a version to play and the tournament length
        initialize players
        announce the winner and deal with a draw situation
        """
        print("pick a version:\n" + Version.versions_menu(self.versions))
        choice = Game.input_int_range(1, len(self.versions))
        print("please pick the tournament length:")
        # input check, we can't use the method because the range has no end
        is_integer = False
        while (not is_integer) or (game_length < 0):
            try:
                game_length = int((input()))
                if game_length < 0:
                    print("please type an positive number")
                is_integer = True
            except Exception as e:
                print("please type a positive integer")
        if game_length ==0:
            print("\n:(")
            return


        self.initialize_players()

        # the tournament
        for i in range(game_length):
            self.game_logic(choice - 1)

        print()  # for the design
        time.sleep(1.5)
        self.announce_winner(choice - 1)
        time.sleep(1.5)
        print("The tournament is over :(\n")
        # print the scores
        for p in self.players:
            print(p.name + "'s score is " + str(p.score))
        time.sleep(3)

    @staticmethod
    def input_int_range(start, end):
        """
        check the user's input
        :param start: start of the range
        :param end: end of the range
        :return: number from the user in the range

        the method is static because the Game variables don't needed
        """
        is_integer = False
        while (not is_integer) or (user_input < start or user_input > end):
            try:
                user_input = int((input()))
                if user_input < start or user_input > end:
                    print("pay attention to the range, " + str(start) + "-" + str(end))
                is_integer = True
            except Exception as e:
                print("please type an integer in range " + str(start) + "-" + str(end))
        return user_input

    def game_logic(self, version_index):
        """
        handle the game logic
        supports any game version of the user
        :param version_index: the index of the user's wanted version
        :return: change the scores of the players
        """
        current_version = self.versions[version_index]
        for p in self.players:
            p.choose_element(current_version.elements)
        print()  # for the design

        e1 = self.players[0].element
        e2 = self.players[1].element

        if e1 in current_version.power_setting[e2] and e2 in current_version.power_setting[e1]:
            print("it's a draw !")
        elif e1 in current_version.power_setting[e2]:
            print(self.players[1].name + " wins at this game!")
            self.players[1].increase_score()
        elif e2 in current_version.power_setting[e1]:
            print(self.players[0].name + " wins at this game!")
            self.players[0].increase_score()
        else:
            print("it's a draw !")

    def announce_winner(self, version_index):
        """
        pick the winner according to the player's score
        give an option to a tiebreaker
        :param version_index: the wanted version's index
        """
        if self.players[0].score > self.players[1].score:
            print(self.players[0].name + " wins the tournament !!!")
        elif self.players[0].score < self.players[1].score:
            print(self.players[1].name + " wins the tournament !!!")
        else:
            print("the tournament ended with a draw :(")
            another_game = (input("want a tiebreaker ?\nanswer with yes\\no\n")).lower()
            # input check
            while another_game != "yes" and another_game != "no":
                another_game = (input("please answer with yes\\no: ")).lower()

            if another_game == "yes":
                self.game_logic(version_index)
                self.announce_winner(version_index)

    def add_user_version(self):
        """
        get information from the user about the file and check if he is valid
        this is a significant part of the project, to handle all the options

        the func convert the information to a Version object
        """
        file_path = input("please type your new version's file path: ")
        while not os.path.isfile(file_path):
            file_path = input("the path you typed is not to a file\nplease try again: ")
        try:
            with open(file_path, "r") as json_file:
                data = json.load(json_file)
        except Exception as e:
            print("The file is not a valid JSON file")
            self.add_user_version()
            return

        while type(data) is not dict:
            print("the structure in your json file should be a dictionary, please fix your file.")
            time.sleep(3)
            file_path = input("please type your fixed file path: ")
            while not os.path.isfile(file_path):
                file_path = input("the path you typed is not valid\nplease try again: ")
            try:
                with open(file_path, "r") as json_file:
                    data = json.load(json_file)
            except Exception as e:
                print("The file is not a valid JSON file")
                self.add_user_version()
                return

        try:
            new_version = Version(data)
        except Exception as e:
            print(e.args[0])
            self.add_user_version()
            return

        print("\nThe name for your version will be \"" + new_version.name + "\"")
        is_change_name = (input("do you want to change the name? answer in yes\\no ")).lower()
        while is_change_name != "no" and is_change_name != "yes":
            is_change_name = (input("please answer with yes\\no: ")).lower()
        if is_change_name == "yes":
            new_version.name = input("Type your wanted name: ")

        self.versions.append(new_version)

    @staticmethod
    def how_to_create_user_version():
        """
        print the steps to add a Version
        I needed a method for it because its integrates the time module
        and to make the design easier for me

        the method is static because I don't need the Game object (versions, players)
        """
        print("To make your own game version you need to follow the steps\n")
        time.sleep(2)
        print("first, create a json file, and write in it the information about your version in the next form:\n")
        time.sleep(1)
        print("write a dict such that the keys are your new game's elements")
        print("each element's value is an array of the other elements that it wins")
        print("each element described by a string!")
        time.sleep(2)
        print("\nfor example Rock Paper Scissors version's file is:")
        print('{"rock":["scissors"], "paper":["rock"], "scissors":["paper"]}\n')
        time.sleep(2)
        print("our recommendation for a better game is to make every element such that")
        print("it wins the same number of elements\n")
        print(
            "common mistakes: elements isn't strings, file is not a JSON file (fix by change the ending to \".jsn\")\n")
        time.sleep(2)

    def rules(self):
        """
        print the rules of the ame
        print a menu of the versions in the game
        print rules to a version according to the user request.
        """
        print(RULES)
        time.sleep(2)
        print(Version.versions_menu(self.versions))
        version_index = Game.input_int_range(1, len(self.versions))
        print(self.versions[version_index - 1].description)
        time.sleep(2)


    def start(self):
        """
        Integrates all the features in the game
        """
        print(SECTION + "\n" + INTRODUCTION + SECTION + "\n\n")
        continue_game = True
        time.sleep(1)
        while continue_game:
            print(MENU)
            # input check
            choice = Game.input_int_range(0, 3)
            print("\n" + SECTION + "\n")

            if choice == 0:
                self.run_game()
            elif choice == 1:
                self.rules()
            elif choice == 2:
                Game.how_to_create_user_version()
                self.add_user_version()
            elif choice == 3:
                print("Bye Bye !")
                continue_game = False

            print("\n" + SECTION + "\n")
