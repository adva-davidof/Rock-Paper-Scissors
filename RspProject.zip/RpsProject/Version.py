import json

FIRST_DEFAULT_VERSION = r"default_versions\version1_rsp.json"
SECOND_DEFAULT_VERSION = r"default_versions\version2_rsp.json"


class Version:
    """
    This class is in charge of making versions
    """

    # throw Exception
    def __init__(self, version_data):
        """
        create a default name to the version
        create a description
        initialize the elements
        checks that all the elements are strings as requested
        convert all the strings to lower case so the comparing will be generic for the user
        :param version_data: dict with the power setting
        """
        self.name = ""
        self.description = ""

        for k in version_data.keys():
            # check the user input (elements(keys) should be strings)
            if type(k) is str:
                self.name += k + " "
            else:
                raise Exception("the elements needs to be strings")

            # case: {"int":[]} - test 5
            if len(version_data[k]) == 0:
                self.description += k + " doesn't wins\n"
            # handle the case that the values are'nt lists
            elif type(version_data[k]) is str:
                self.description = self.description + k + " wins " + version_data[k] + "\n"
            #  if the values are lists
            elif type(version_data[k]) is list:
                # check the user input (elements should be strings)
                if type(version_data[k][0]) is str:
                    self.description = self.description + k + " wins " + version_data[k][0]
                else:
                    raise Exception("the elements needs to be strings")

                for i in range(1, len(version_data[k])):
                    if type(version_data[k][i]) is str:
                        self.description += " and " + version_data[k][i]
                    else:
                        raise Exception("the elements needs to be strings")
                self.description += "\n"
            # its not a string or list of strings -> not as requested
            else:
                raise Exception("the elements needs to be strings")

        # remove the last characters because they are unimportant (they are " " or "\n")
        self.name = self.name[0:len(self.name) - 1]
        self.description = self.description[0:len(self.description) - 1]

        # convert the strings to low cased
        version_data_lower = {}
        for k in version_data.keys():
            value = version_data[k]
            list_lower = []
            if type(value) is str:
                list_lower.append(value)
            elif type(value) is list:
                for l in value:
                    if type(l) is not str:
                        raise Exception("the elements needs to be strings")
                    list_lower.append(l.lower())
            else:
                raise Exception("the elements needs to be strings")
            version_data_lower[k.lower()] = list_lower

        self.power_setting = version_data_lower
        self.elements = version_data_lower

    # throw Exception
    @staticmethod
    def create_with_file(json_file):
        """
        needed this method to split responsibilities

        open the file and create a new Version object according to the file's data
        :param json_file: the path to the json file
        :return: a new version object
        """
        try:
            with open(json_file, "r") as jsonFile:
                data = json.load(jsonFile)
        except:
            raise Exception("The file is not a valid JSON file")

        v = Version(data)
        return v

    @staticmethod
    def create_with_file_and_name(json_file_path, version_name):
        """
           needed this method to override constructors

           create a new version by a file path and update his name
           :param json_file_path: the path to the json file
           :param version_name: the version's update name
           :return: a new version object
           """
        v = Version(json_file_path)
        v.name = version_name
        return v

    @staticmethod
    def insert_default_versions():
        """
        creating the default versions
        it is a static method because there is no need in a self Version object
        :return:
        """
        default_versions_paths = [FIRST_DEFAULT_VERSION, SECOND_DEFAULT_VERSION]
        default_versions = []

        for i in range(len(default_versions_paths)):
            v = Version.create_with_file(default_versions_paths[i])
            default_versions.append(v)
        return default_versions

    @staticmethod
    def versions_menu(versions):
        """
        create a numbred menu to the versions
        this method is static because it not depends on a self Version object
        :param versions: all the versions in the menu
        :return:
        """
        menu = ""
        for i in range(len(versions)):
            menu = menu + str(i + 1) + "- for \"" + versions[i].name + "\"" + "\n"
        return menu[0:len(menu) - 1]  # remove the last not important character ("\n")
