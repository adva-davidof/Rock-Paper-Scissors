class Player:
    """
    The class Player is in charge of any player and actions like saving his score
    """

    def __init__(self, my_name):
        """
        init the player object
        initialize the score and chosen element
        :param my_name: the player's name
        """
        self.score = 0
        self.name = my_name
        self.element = ""

    def choose_element(self, elements):
        """
        gets input from the user about his chosen element , check if he is valid and update the chosen element
        :param elements: all the possibility elements
        :return:
        """
        e = (input(self.name + " please choose an element:")).lower()
        while e not in elements:
            e = (input(self.name + " didn't choose the element correctly,  please choose again:")).lower()
        self.element = e

    def increase_score(self):
        """
          increase the player score
          """
        self.score += 1
